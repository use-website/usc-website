
# USC Website (Hugo)

This is a draft Hugo site for Universal Safety Consultants.

Structure:
- content/
- layouts/
- static/
